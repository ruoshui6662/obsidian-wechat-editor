"use strict";
(() => {
  // packages/core/src/types.ts
  var LayoutError = class extends Error {
    constructor(code, message, occurrenceIds = []) {
      super(message);
      this.code = code;
      this.occurrenceIds = occurrenceIds;
      this.name = "LayoutError";
    }
  };

  // packages/core/src/protocol.ts
  var MAX_MESSAGE_BYTES = 16 * 1024 * 1024;
  function isAccount(value) {
    const a = value;
    return !!a && typeof a.id === "string" && a.id.length > 0 && a.id.length <= 256 && typeof a.name === "string" && a.name.length <= 256;
  }
  function isWechatImageURL(value) {
    if (typeof value !== "string") return false;
    try {
      const u = new URL(value);
      return ["https:", "http:"].includes(u.protocol) && u.hostname === "mmbiz.qpic.cn" && !u.username && !u.password;
    } catch {
      return false;
    }
  }
  function parseMessage(raw) {
    if (new TextEncoder().encode(raw).length > MAX_MESSAGE_BYTES) throw Error("\u6D88\u606F\u8FC7\u5927");
    const m = JSON.parse(raw);
    if (!m || m.version !== 1 || typeof m.requestId !== "string" || !m.requestId || m.requestId.length > 128 || !["hello", "hello-ok", "account", "account-check", "upload", "upload-result", "error", "cancel", "ping", "pong", "discover", "discovery", "pair-request", "pair-waiting", "pair-granted", "pair-denied"].includes(m.type) || m.payload === null || typeof m.payload !== "object") throw Error("\u6D88\u606F\u683C\u5F0F\u65E0\u6548");
    if (m.jobId !== void 0 && (typeof m.jobId !== "string" || m.jobId.length > 128)) throw Error("\u4EFB\u52A1\u6807\u8BC6\u65E0\u6548");
    if (m.accountId !== void 0 && (typeof m.accountId !== "string" || m.accountId.length > 256)) throw Error("\u8D26\u53F7\u6807\u8BC6\u65E0\u6548");
    const p = m.payload;
    if (Array.isArray(p)) throw Error("\u6D88\u606F\u683C\u5F0F\u65E0\u6548");
    const label = (v, max = 128) => typeof v === "string" && v.length > 0 && v.length <= max && !/[\u0000-\u001f\u007f]/.test(v);
    if (m.type === "pair-request" && (!label(p.bridgeId) || !label(p.clientId) || !label(p.name, 80))) throw Error("\u6388\u6743\u8BF7\u6C42\u65E0\u6548");
    if (m.type === "discovery" && (p.product !== "wechat-layout" || !label(p.bridgeId) || !label(p.name, 80))) throw Error("\u670D\u52A1\u4FE1\u606F\u65E0\u6548");
    if (m.type === "pair-granted" && (!label(p.bridgeId) || !label(p.name, 80) || typeof p.token !== "string" || !/^[a-f0-9]{64}$/.test(p.token))) throw Error("\u6388\u6743\u4FE1\u606F\u65E0\u6548");
    if (m.type === "hello" && p.clientId !== void 0 && !label(p.clientId)) throw Error("\u52A9\u624B\u6807\u8BC6\u65E0\u6548");
    if (m.type === "hello" && (typeof p.token !== "string" || p.token.length > 256 || p.account !== null && !isAccount(p.account))) throw Error("\u914D\u5BF9\u6570\u636E\u65E0\u6548");
    if (m.type === "account" && p.account !== null && !isAccount(p.account)) throw Error("\u8D26\u53F7\u6570\u636E\u65E0\u6548");
    if (m.type === "upload-result" && (typeof p.key !== "string" || !isWechatImageURL(p.url))) throw Error("\u4E0A\u4F20\u8FD4\u56DE\u5730\u5740\u65E0\u6548");
    if (m.type === "upload" && (typeof p.key !== "string" || typeof p.base64 !== "string" || typeof p.filename !== "string" || p.filename.length > 512 || !["image/png", "image/jpeg", "image/gif", "image/webp"].includes(p.mime) || !Number.isInteger(p.size) || p.size <= 0 || p.size > 10 * 1024 * 1024 || typeof p.sha256 !== "string" || !/^[a-f0-9]{64}$/.test(p.sha256))) throw Error("\u4E0A\u4F20\u6570\u636E\u65E0\u6548");
    if (m.type === "error" && (typeof p.message !== "string" || p.message.length > 1e3 || typeof p.code !== "string" || p.code.length > 128)) throw Error("\u9519\u8BEF\u6D88\u606F\u65E0\u6548");
    return m;
  }

  // packages/extension/src/connection.ts
  var bounded = (task, ms, message) => new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(Error(message)), ms);
    task.then((v) => {
      clearTimeout(timer);
      resolve(v);
    }, (e) => {
      clearTimeout(timer);
      reject(e);
    });
  });
  var ExtensionConnection = class {
    constructor(options) {
      this.options = options;
    }
    socket = null;
    heartbeat = null;
    deadline = null;
    reconnect = null;
    generation = 0;
    uploads = /* @__PURE__ */ new Map();
    blocked = false;
    attempts = 0;
    authenticated = false;
    startedAt = 0;
    replyAt = 0;
    refreshTask = null;
    state = { phase: "idle", message: "\u5C1A\u672A\u8FDE\u63A5 Obsidian", account: null, wechatMessage: "\u7B49\u5F85\u68C0\u67E5\u516C\u4F17\u53F7\u540E\u53F0" };
    publish(patch) {
      this.state = { ...this.state, ...patch };
      this.options.status(this.state.message);
      this.options.state?.({ ...this.state });
    }
    stop() {
      this.generation++;
      if (this.heartbeat) clearInterval(this.heartbeat);
      if (this.reconnect) clearTimeout(this.reconnect);
      if (this.deadline) clearTimeout(this.deadline);
      this.heartbeat = null;
      this.reconnect = null;
      this.deadline = null;
      this.authenticated = false;
      this.refreshTask = null;
      const socket2 = this.socket;
      this.socket = null;
      for (const c of this.uploads.values()) c.abort();
      this.uploads.clear();
      socket2?.close();
    }
    async restore(force = false) {
      if (force) {
        this.blocked = false;
        this.attempts = 0;
      }
      if (this.blocked) return;
      if (!force && this.socket && [0, 1].includes(this.socket.readyState)) {
        if (Date.now() - (this.authenticated ? this.replyAt : this.startedAt) < (this.authenticated ? 45e3 : 1e4)) return;
      } else if (!force && this.reconnect) return;
      this.stop();
      const generation = this.generation, current = () => generation === this.generation;
      this.startedAt = Date.now();
      this.publish({ phase: this.attempts ? "reconnecting" : "connecting", message: "\u6B63\u5728\u8FDE\u63A5 Obsidian\u2026", account: null });
      let pairing;
      try {
        pairing = await this.options.load();
        if (!current()) return;
        if (!pairing) {
          this.publish({ phase: "idle", message: "\u70B9\u51FB\u8FDE\u63A5 Obsidian" });
          return;
        }
        if (this.options.locate) pairing = await this.options.locate(pairing);
        if (!current()) return;
      } catch {
        if (current()) this.retry("\u672A\u627E\u5230 Obsidian\uFF0C\u8BF7\u4FDD\u6301\u7B14\u8BB0\u5E93\u6253\u5F00");
        return;
      }
      let endpoint;
      try {
        endpoint = new URL(pairing.endpoint);
      } catch {
        this.publish({ phase: "approval", message: "\u8FDE\u63A5\u4FE1\u606F\u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5" });
        return;
      }
      if (endpoint.protocol !== "ws:" || endpoint.hostname !== "127.0.0.1" || !/^\d+$/.test(endpoint.port) || !/^[a-f0-9]{64}$/.test(pairing.token)) {
        this.publish({ phase: "approval", message: "\u8FDE\u63A5\u4FE1\u606F\u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5" });
        return;
      }
      let socket2;
      try {
        socket2 = this.options.socket(endpoint.href);
      } catch {
        this.retry("\u65E0\u6CD5\u5EFA\u7ACB\u672C\u673A\u8FDE\u63A5");
        return;
      }
      this.socket = socket2;
      const alive = () => current() && this.socket === socket2;
      const send = (m) => {
        if (alive() && socket2.readyState === 1) socket2.send(JSON.stringify(m));
      };
      this.deadline = setTimeout(() => {
        if (alive()) socket2.close(4e3, "\u8FDE\u63A5\u8D85\u65F6");
      }, 1e4);
      const read = async () => this.options.resolveSession ? this.options.resolveSession() : { tabId: pairing.tabId, account: await this.options.readAccount(pairing.tabId) };
      const refresh = () => {
        if (this.refreshTask) return this.refreshTask;
        const task = bounded(read(), 7e3, "\u540E\u53F0\u8BFB\u53D6\u8D85\u65F6\uFF0C\u8BF7\u6253\u5F00\u516C\u4F17\u53F7\u540E\u53F0").then((session) => {
          if (!alive()) return null;
          this.publish({ account: session.account, wechatMessage: "\u540E\u53F0\u5DF2\u5C31\u7EEA" });
          send({ version: 1, type: "account", requestId: crypto.randomUUID(), payload: { account: session.account } });
          return session;
        }, (error) => {
          if (alive()) {
            this.publish({ account: null, wechatMessage: error instanceof Error ? error.message : "\u8BF7\u6253\u5F00\u5DF2\u767B\u5F55\u7684\u516C\u4F17\u53F7\u540E\u53F0" });
            send({ version: 1, type: "account", requestId: crypto.randomUUID(), payload: { account: null } });
          }
          return null;
        }).finally(() => {
          if (this.refreshTask === task) this.refreshTask = null;
        });
        this.refreshTask = task;
        return task;
      };
      this.refresh = () => this.authenticated && alive() ? refresh() : Promise.resolve(null);
      socket2.onopen = () => {
        if (!alive()) return;
        this.replyAt = Date.now();
        send({ version: 1, type: "hello", requestId: crypto.randomUUID(), payload: { token: pairing.token, clientId: pairing.clientId, account: null } });
        this.heartbeat = setInterval(() => {
          if (!alive()) return;
          if (Date.now() - this.replyAt > 45e3) {
            socket2.close(4e3, "\u5FC3\u8DF3\u8D85\u65F6");
            return;
          }
          send({ version: 1, type: "ping", requestId: crypto.randomUUID(), payload: {} });
          if (this.authenticated) void refresh();
        }, 2e4);
      };
      socket2.onmessage = async (event) => {
        if (!alive()) return;
        try {
          const m = parseMessage(String(event.data));
          if (m.type === "hello-ok") {
            if (this.authenticated) return;
            this.authenticated = true;
            if (this.deadline) clearTimeout(this.deadline);
            this.attempts = 0;
            this.replyAt = Date.now();
            this.publish({ phase: "connected", message: "Obsidian \u5DF2\u8FDE\u63A5", name: m.payload.name || pairing.name, connectedAt: Date.now(), lastReplyAt: this.replyAt, wechatMessage: "\u6B63\u5728\u8BC6\u522B\u516C\u4F17\u53F7\u2026" });
            if (m.payload.bridgeId) {
              pairing = { ...pairing, bridgeId: m.payload.bridgeId, name: m.payload.name };
              void this.options.save?.(pairing).catch(() => {
              });
            }
            await refresh();
            return;
          }
          if (!this.authenticated) return;
          if (m.type === "pong") {
            this.replyAt = Date.now();
            this.publish({ lastReplyAt: this.replyAt });
            return;
          }
          if (m.type === "account-check") {
            const session = await refresh();
            send({ version: 1, type: "account", requestId: m.requestId, payload: { account: session?.account ?? null } });
            return;
          }
          if (m.type === "cancel") {
            this.uploads.get(m.requestId)?.abort();
            return;
          }
          if (m.type !== "upload") return;
          const controller = new AbortController();
          this.uploads.set(m.requestId, controller);
          try {
            const session = await refresh();
            if (!alive() || controller.signal.aborted) return;
            if (!session || session.account.id !== m.accountId) throw new LayoutError("account-changed", "\u516C\u4F17\u53F7\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u590D\u5236\u3002");
            const raw = atob(m.payload.base64), bytes = Uint8Array.from(raw, (c) => c.charCodeAt(0));
            const hash = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))).map((n) => n.toString(16).padStart(2, "0")).join("");
            if (bytes.length !== m.payload.size || hash !== m.payload.sha256) throw new LayoutError("asset-integrity", "\u56FE\u7247\u6570\u636E\u6821\u9A8C\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002");
            if (!alive() || controller.signal.aborted) return;
            const url = await this.options.upload(session.tabId, { key: m.payload.key, bytes, mime: m.payload.mime, filename: m.payload.filename, occurrenceIds: [] }, m.accountId, controller.signal);
            if (!controller.signal.aborted) send({ ...m, type: "upload-result", payload: { key: m.payload.key, url } });
          } catch (e) {
            if (!controller.signal.aborted) send({ ...m, type: "error", payload: { code: e instanceof LayoutError ? e.code : "upload-failed", message: e instanceof Error ? e.message.slice(0, 1e3) : "\u4E0A\u4F20\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002" } });
          } finally {
            if (this.uploads.get(m.requestId) === controller) this.uploads.delete(m.requestId);
          }
        } catch {
          if (alive()) socket2.close(4003, "\u6D88\u606F\u4E0D\u517C\u5BB9\uFF0C\u8BF7\u66F4\u65B0\u4E24\u7AEF\u63D2\u4EF6");
        }
      };
      socket2.onclose = (event) => {
        if (!alive()) return;
        this.stop();
        const revoked = event?.code === 4003;
        if (revoked) {
          this.blocked = true;
          this.publish({ phase: "approval", account: null, message: "\u8FDE\u63A5\u5DF2\u5931\u6548\uFF0C\u8BF7\u70B9\u51FB\u91CD\u65B0\u8FDE\u63A5", lastDisconnect: "\u6388\u6743\u5931\u6548\u6216\u8FDE\u63A5\u88AB\u66FF\u6362", disconnectedAt: Date.now() });
        } else this.retry("\u672C\u673A\u8FDE\u63A5\u4E2D\u65AD\uFF0C\u6B63\u5728\u81EA\u52A8\u6062\u590D");
      };
      socket2.onerror = () => {
        if (alive()) this.publish({ message: "\u6B63\u5728\u7B49\u5F85 Obsidian\u2026" });
      };
    }
    retry(reason) {
      this.publish({ phase: "reconnecting", message: reason, account: null, lastDisconnect: reason, disconnectedAt: Date.now() });
      const delay = Math.min(15e3, 1e3 * 2 ** Math.min(this.attempts++, 4));
      this.reconnect = setTimeout(() => {
        this.reconnect = null;
        void this.restore();
      }, delay);
    }
    refresh = () => Promise.resolve(null);
    async refreshAccount() {
      await this.refresh();
    }
  };

  // packages/extension/src/assistant.ts
  var AssistantController = class {
    constructor(options) {
      this.options = options;
    }
    snapshot = { phase: "idle", message: "\u8FDE\u63A5\u540E\u5373\u53EF\u4ECE Obsidian \u590D\u5236\u56FE\u6587", account: null, wechatMessage: "\u81EA\u52A8\u8BC6\u522B\u5DF2\u767B\u5F55\u7684\u516C\u4F17\u53F7" };
    pending = null;
    generation = 0;
    writes = Promise.resolve();
    initialized = null;
    write(task) {
      const next = this.writes.then(task);
      this.writes = next.catch(() => {
      });
      return next;
    }
    async remember(pairing) {
      await this.write(async () => {
        const saved = await this.options.store.get();
        if (!saved.paused && saved.pairing?.token === pairing.token) await this.options.store.set({ pairing });
      });
    }
    publish(patch) {
      this.snapshot = { ...this.snapshot, ...patch };
      this.options.publish({ ...this.snapshot });
    }
    update(state) {
      if (!this.pending) this.publish({ ...state, busy: false, candidates: void 0 });
    }
    initialize() {
      return this.initialized ?? (this.initialized = this.load());
    }
    async load() {
      const generation = this.generation, saved = await this.options.store.get();
      if (generation !== this.generation) return;
      const previous = saved.assistantState;
      if (previous && typeof previous === "object") {
        for (const key of ["connectedAt", "disconnectedAt"]) if (typeof previous[key] === "number" && Number.isFinite(previous[key])) this.snapshot[key] = previous[key];
        if (typeof previous.lastDisconnect === "string") this.snapshot.lastDisconnect = previous.lastDisconnect.slice(0, 200);
      }
      if (saved.paused && saved.pairing) this.publish({ phase: "paused", message: "\u81EA\u52A8\u8FDE\u63A5\u5DF2\u6682\u505C", name: saved.pairing?.name });
      else if (saved.pairing) await this.options.connection.restore();
      else this.publish({ phase: "idle" });
    }
    async refresh() {
      const generation = this.generation;
      await this.initialize();
      if (generation !== this.generation) return this.snapshot;
      const saved = await this.options.store.get();
      if (generation !== this.generation) return this.snapshot;
      if (!saved.paused && !this.pending) {
        await this.options.connection.restore();
        if (generation === this.generation) await this.options.connection.refreshAccount();
      }
      return this.snapshot;
    }
    async connect(bridgeId) {
      if (this.pending) return;
      const generation = ++this.generation, controller = new AbortController();
      this.pending = controller;
      await this.initialize();
      if (generation !== this.generation) return;
      this.options.connection.stop();
      this.publish({ phase: "connecting", busy: true, candidates: void 0, message: "\u6B63\u5728\u5BFB\u627E Obsidian\u2026", account: null });
      try {
        const found = await this.options.discover();
        if (generation !== this.generation) return;
        if (!found.length) throw Error("\u672A\u627E\u5230 Obsidian\uFF0C\u8BF7\u6253\u5F00\u7B14\u8BB0\u5E93\u5E76\u542F\u7528\u6392\u7248\u63D2\u4EF6");
        const target = bridgeId ? found.find((b) => b.bridgeId === bridgeId) : found.length === 1 ? found[0] : void 0;
        if (!target) {
          this.publish({ phase: "idle", message: "\u9009\u62E9\u8981\u8FDE\u63A5\u7684\u7B14\u8BB0\u5E93", candidates: found });
          return;
        }
        let saved = await this.options.store.get();
        let clientId = saved.clientId;
        if (typeof clientId !== "string") {
          clientId = crypto.randomUUID();
          await this.write(() => this.options.store.set({ clientId }));
        }
        const pairing = await this.options.pair(target, clientId, () => {
          if (generation === this.generation) this.publish({ phase: "approval", message: "\u8BF7\u5728 Obsidian \u4E2D\u5141\u8BB8\u8FDE\u63A5", name: target.name });
        }, controller.signal);
        if (generation !== this.generation) return;
        await this.write(async () => {
          if (generation === this.generation) await this.options.store.set({ pairing, paused: false });
        });
        if (generation !== this.generation) return;
        this.pending = null;
        this.publish({ name: target.name, busy: false });
        await this.options.connection.restore(true);
      } catch (error) {
        if (generation === this.generation) this.publish({ phase: "idle", message: error instanceof Error ? error.message : "\u8FDE\u63A5\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5" });
      } finally {
        if (generation === this.generation) {
          this.pending = null;
          this.publish({ busy: false });
        }
      }
    }
    async retry() {
      if (this.pending) return;
      const generation = ++this.generation;
      await this.initialize();
      if (generation !== this.generation) return;
      await this.write(async () => {
        if (generation === this.generation) await this.options.store.set({ paused: false });
      });
      if (generation !== this.generation) return;
      await this.options.connection.restore(true);
      if (generation === this.generation) await this.options.connection.refreshAccount();
    }
    async pause() {
      this.generation++;
      this.pending?.abort();
      this.pending = null;
      this.options.connection.stop();
      await this.write(() => this.options.store.set({ paused: true }));
      this.publish({ phase: "paused", message: "\u81EA\u52A8\u8FDE\u63A5\u5DF2\u6682\u505C", account: null, busy: false, candidates: void 0 });
    }
    async unlink() {
      this.generation++;
      this.pending?.abort();
      this.pending = null;
      this.options.connection.stop();
      await this.write(() => this.options.store.set({ paused: true }));
      await this.write(() => this.options.store.remove("pairing"));
      this.publish({ phase: "idle", message: "\u5DF2\u79FB\u9664\u6B64\u6D4F\u89C8\u5668\u7684\u8FDE\u63A5\u8BB0\u5F55", account: null, name: void 0, busy: false, candidates: void 0 });
    }
  };

  // packages/extension/src/local-bridge.ts
  var ENDPOINTS = Array.from({ length: 10 }, (_, i) => `ws://127.0.0.1:${17836 + i}`);
  function checkEndpoint(endpoint) {
    const u = new URL(endpoint);
    if (u.protocol !== "ws:" || u.hostname !== "127.0.0.1" || !u.port || u.username || u.password || u.search || u.hash || u.pathname !== "/") throw Error("\u65E0\u6548\u7684\u672C\u673A\u5730\u5740");
  }
  async function discoverBridges(factory, endpoints = ENDPOINTS) {
    const results = await Promise.all(endpoints.map((endpoint) => new Promise((resolve) => {
      let socket2;
      try {
        checkEndpoint(endpoint);
        socket2 = factory(endpoint);
      } catch {
        resolve(null);
        return;
      }
      let done = false;
      const requestId = crypto.randomUUID();
      const timer = setTimeout(() => finish(null), 1200);
      const finish = (value) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        socket2.close();
        resolve(value);
      };
      socket2.onopen = () => socket2.send(JSON.stringify({ version: 1, type: "discover", requestId, payload: {} }));
      socket2.onmessage = (event) => {
        try {
          const m = parseMessage(String(event.data));
          if (m.type !== "discovery" || m.requestId !== requestId) return;
          finish({ endpoint, bridgeId: m.payload.bridgeId, name: m.payload.name });
        } catch {
          finish(null);
        }
      };
      socket2.onerror = () => finish(null);
      socket2.onclose = () => finish(null);
    })));
    return results.filter((r) => !!r);
  }
  async function locatePairing(pairing, factory, endpoints = ENDPOINTS) {
    checkEndpoint(pairing.endpoint);
    if (!pairing.bridgeId) return pairing;
    const preferred = await discoverBridges(factory, [pairing.endpoint]);
    let target = preferred.find((b) => b.bridgeId === pairing.bridgeId);
    if (!target) target = (await discoverBridges(factory, endpoints.filter((e) => e !== pairing.endpoint))).find((b) => b.bridgeId === pairing.bridgeId);
    if (!target) throw Error("\u8BF7\u6253\u5F00\u5DF2\u8FDE\u63A5\u7684 Obsidian \u7B14\u8BB0\u5E93");
    return { ...pairing, endpoint: target.endpoint, name: target.name };
  }
  function requestPairing(bridge, clientId, factory, waiting, signal) {
    return new Promise((resolve, reject) => {
      if (signal.aborted) {
        reject(Error("\u5DF2\u53D6\u6D88\u8FDE\u63A5"));
        return;
      }
      let socket2;
      try {
        checkEndpoint(bridge.endpoint);
        socket2 = factory(bridge.endpoint);
      } catch (e) {
        reject(e);
        return;
      }
      const requestId = crypto.randomUUID();
      let done = false;
      let keepalive;
      const finish = (error, pairing) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        clearInterval(keepalive);
        signal.removeEventListener("abort", abort);
        socket2.close();
        if (error) reject(error);
        else resolve(pairing);
      };
      const timer = setTimeout(() => finish(Error("\u8FDE\u63A5\u786E\u8BA4\u5DF2\u8D85\u65F6\uFF0C\u8BF7\u91CD\u8BD5")), 95e3), abort = () => finish(Error("\u5DF2\u53D6\u6D88\u8FDE\u63A5"));
      signal.addEventListener("abort", abort, { once: true });
      socket2.onopen = () => {
        socket2.send(JSON.stringify({ version: 1, type: "pair-request", requestId, payload: { bridgeId: bridge.bridgeId, clientId, name: "\u516C\u4F17\u53F7\u56FE\u7247\u52A9\u624B" } }));
        keepalive = setInterval(() => {
          if (socket2.readyState === 1) socket2.send(JSON.stringify({ version: 1, type: "ping", requestId: crypto.randomUUID(), payload: {} }));
        }, 2e4);
      };
      socket2.onmessage = (event) => {
        try {
          const m = parseMessage(String(event.data));
          if (m.requestId !== requestId) return;
          if (m.type === "pair-waiting") waiting();
          else if (m.type === "pair-denied") finish(Error("\u5DF2\u5728 Obsidian \u53D6\u6D88\u8FDE\u63A5"));
          else if (m.type === "pair-granted" && m.payload.bridgeId === bridge.bridgeId) finish(void 0, { endpoint: bridge.endpoint, token: m.payload.token, clientId, bridgeId: bridge.bridgeId, name: m.payload.name });
        } catch {
          finish(Error("\u6388\u6743\u4FE1\u606F\u65E0\u6548\uFF0C\u8BF7\u66F4\u65B0\u4E24\u7AEF\u63D2\u4EF6"));
        }
      };
      socket2.onerror = () => finish(Error("\u65E0\u6CD5\u8FDE\u63A5 Obsidian\uFF0C\u8BF7\u4FDD\u6301\u7B14\u8BB0\u5E93\u6253\u5F00"));
      socket2.onclose = () => finish(Error("\u8FDE\u63A5\u672A\u5B8C\u6210\uFF0C\u8BF7\u56DE\u5230 Obsidian \u68C0\u67E5\u540E\u91CD\u8BD5"));
    });
  }

  // packages/extension/src/wechat-target.ts
  var timeout = (task) => new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(Error("\u540E\u53F0\u54CD\u5E94\u8D85\u65F6")), 5e3);
    task.then((v) => {
      clearTimeout(timer);
      resolve(v);
    }, (e) => {
      clearTimeout(timer);
      reject(e);
    });
  });
  async function resolveWechatSession(port) {
    const [all, focused] = await Promise.all([port.tabs(), port.focused()]);
    const tabs = all.filter((t) => Number.isInteger(t.id) && t.url?.startsWith("https://mp.weixin.qq.com/") && !t.discarded && !t.frozen);
    if (!tabs.length) throw new LayoutError("wechat-tab", "\u8BF7\u6253\u5F00\u5DF2\u767B\u5F55\u7684\u516C\u4F17\u53F7\u540E\u53F0");
    const preferred = tabs.find((t) => focused.some((f) => f.id === t.id));
    const read = async (t) => ({ tabId: t.id, account: await timeout(port.read(t.id)) });
    if (preferred) {
      try {
        return await read(preferred);
      } catch {
        throw new LayoutError("wechat-login", "\u8BF7\u5728\u5F53\u524D\u516C\u4F17\u53F7\u540E\u53F0\u5B8C\u6210\u767B\u5F55\uFF0C\u6216\u91CD\u65B0\u6253\u5F00\u540E\u53F0");
      }
    }
    const results = await Promise.allSettled(tabs.slice(0, 8).map(read));
    const sessions = results.flatMap((r) => r.status === "fulfilled" ? [r.value] : []);
    if (new Set(sessions.map((s) => s.account.id)).size > 1) throw new LayoutError("wechat-ambiguous", "\u8BF7\u5148\u6253\u5F00\u8981\u4F7F\u7528\u7684\u516C\u4F17\u53F7\u540E\u53F0\uFF0C\u518D\u56DE\u5230 Obsidian \u590D\u5236");
    if (!sessions.length) throw new LayoutError("wechat-login", "\u8BF7\u5728\u516C\u4F17\u53F7\u540E\u53F0\u5B8C\u6210\u767B\u5F55\uFF1B\u5982\u5DF2\u767B\u5F55\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u540E\u53F0");
    return sessions[0];
  }

  // packages/extension/src/wechat-page.ts
  async function wechatPageOperation(operation, expectedAccountId, asset) {
    const timeout2 = new AbortController();
    const timer = setTimeout(() => timeout2.abort(), operation === "read" ? 6e3 : 85e3);
    try {
      const readContext = async () => {
        const response2 = await fetch("https://mp.weixin.qq.com/", { credentials: "include", cache: "no-store", signal: timeout2.signal });
        if (!response2.ok) throw Error("\u65E0\u6CD5\u8BFB\u53D6\u516C\u4F17\u53F7\u767B\u5F55\u72B6\u6001\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u540E\u53F0\u3002");
        const html = await response2.text();
        const read = (key) => {
          const match = html.match(new RegExp(String.raw`(?:^|[^\w$])["']?${key}["']?\s*[:=]\s*(?:"((?:\\.|[^"\\])*)"|'((?:\\.|[^'\\])*)'|(\d+))`));
          return (match?.[1] ?? match?.[2] ?? match?.[3] ?? "").replace(/\\x([a-f\d]{2})/gi, (_, n) => String.fromCharCode(parseInt(n, 16))).replace(/\\u([a-f\d]{4})/gi, (_, n) => String.fromCharCode(parseInt(n, 16))).replace(/\\([\\"'])/g, "$1").replace(/&amp;/g, "&");
        };
        const context2 = { t: read("t") || read("token"), user_name: read("user_name"), nick_name: read("nick_name"), ticket: read("ticket"), time: read("time") };
        if (!context2.user_name || !context2.t) throw Error("\u672A\u8BC6\u522B\u5230\u516C\u4F17\u53F7\uFF0C\u8BF7\u5148\u767B\u5F55\u6216\u91CD\u65B0\u6253\u5F00\u516C\u4F17\u53F7\u540E\u53F0\u3002");
        return context2;
      };
      let bytes;
      if (operation === "upload") {
        if (!asset) throw Error("\u56FE\u7247\u6570\u636E\u4E3A\u7A7A\uFF0C\u8BF7\u91CD\u65B0\u590D\u5236\u3002");
        const raw = atob(asset.base64);
        bytes = new Uint8Array(raw.length);
        for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
        const hash = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))).map((n) => n.toString(16).padStart(2, "0")).join("");
        if (bytes.byteLength !== asset.size || hash !== asset.sha256 || bytes.byteLength > 10 * 1024 * 1024) throw Error("\u56FE\u7247\u4F20\u8F93\u6821\u9A8C\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u590D\u5236\u3002");
      }
      const context = await readContext(), account = { id: context.user_name, name: context.nick_name || context.user_name };
      if (expectedAccountId && account.id !== expectedAccountId) return { ok: false, code: "account-changed", message: "\u516C\u4F17\u53F7\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u590D\u5236\u3002" };
      if (operation === "read") return { ok: true, account };
      if (!asset || !bytes || !context.ticket) throw Error("\u5F53\u524D\u767B\u5F55\u7F3A\u5C11\u4E0A\u4F20\u4FE1\u606F\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u516C\u4F17\u53F7\u540E\u53F0\u3002");
      const form = new FormData();
      const now = Date.now();
      form.append("type", asset.mime);
      form.append("id", String(now));
      form.append("name", asset.filename);
      form.append("lastModifiedDate", (/* @__PURE__ */ new Date()).toString());
      form.append("size", String(bytes.byteLength));
      form.append("file", new Blob([bytes], { type: asset.mime }), asset.filename);
      const url = new URL("https://mp.weixin.qq.com/cgi-bin/filetransfer");
      const params = { action: "upload_material", f: "json", scene: "8", writetype: "doublewrite", groupid: "1", ticket_id: account.id, ticket: String(context.ticket), svr_time: String(context.time || Math.floor(now / 1e3)), token: String(context.t), lang: "zh_CN", seq: String(now), t: String(Math.random()) };
      for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
      const response = await fetch(url.href, { method: "POST", credentials: "include", body: form, signal: timeout2.signal });
      if (!response.ok) throw Error(`\u56FE\u7247\u4E0A\u4F20\u8BF7\u6C42\u5931\u8D25\uFF08HTTP ${response.status}\uFF09\u3002`);
      const result = await response.json();
      if (result.base_resp?.ret !== void 0 && result.base_resp.ret !== 0 || result.base_resp?.err_msg !== "ok") throw Error(`\u5FAE\u4FE1\u62D2\u7EDD\u56FE\u7247\u4E0A\u4F20\uFF08\u4EE3\u7801 ${String(result.base_resp?.ret ?? "\u672A\u77E5")}\uFF09\uFF0C\u8BF7\u68C0\u67E5\u767B\u5F55\u72B6\u6001\u540E\u91CD\u8BD5\u3002`);
      let imageURL;
      try {
        imageURL = new URL(result.cdn_url);
      } catch {
        throw Error("\u5FAE\u4FE1\u672A\u8FD4\u56DE\u6709\u6548\u56FE\u7247\u5730\u5740\uFF0C\u8BF7\u91CD\u8BD5\u3002");
      }
      if (imageURL.hostname !== "mmbiz.qpic.cn" || !["https:", "http:"].includes(imageURL.protocol) || imageURL.username || imageURL.password) throw Error("\u5FAE\u4FE1\u672A\u8FD4\u56DE\u6709\u6548\u56FE\u7247\u5730\u5740\uFF0C\u8BF7\u91CD\u8BD5\u3002");
      const current = await readContext();
      if (current.user_name !== account.id) return { ok: false, code: "account-changed", message: "\u4E0A\u4F20\u671F\u95F4\u516C\u4F17\u53F7\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u590D\u5236\u3002" };
      return { ok: true, account, url: imageURL.href };
    } catch (e) {
      return { ok: false, code: "wechat-upload", message: timeout2.signal.aborted ? "\u56FE\u7247\u4E0A\u4F20\u8D85\u65F6\uFF0C\u8BF7\u91CD\u8BD5\u3002" : e instanceof Error ? e.message : "\u5FAE\u4FE1\u56FE\u7247\u5904\u7406\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002" };
    } finally {
      clearTimeout(timer);
    }
  }

  // packages/extension/src/wechat-adapter.ts
  var run = async (tabId, operation, accountId, asset) => {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.url?.startsWith("https://mp.weixin.qq.com/")) throw new LayoutError("wechat-tab", "\u8BF7\u9009\u62E9\u5DF2\u767B\u5F55\u7684\u516C\u4F17\u53F7\u540E\u53F0\u6807\u7B7E\u9875\u3002");
    const result = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func: wechatPageOperation, args: [operation, accountId || "", asset || null] });
    if (!result[0]?.result) throw new LayoutError("wechat-page", "\u65E0\u6CD5\u8BFB\u53D6\u516C\u4F17\u53F7\u540E\u53F0\uFF0C\u8BF7\u5237\u65B0\u8BE5\u6807\u7B7E\u9875\u3002");
    return result[0].result;
  };
  async function readWechatAccount(tabId) {
    const r = await run(tabId, "read");
    if (!r.ok || !r.account) throw new LayoutError(r.code || "wechat-account", r.message || "\u672A\u8BC6\u522B\u516C\u4F17\u53F7\u3002");
    return r.account;
  }
  async function uploadWechatImage(tabId, asset, expectedAccountId, signal, runner = run, timeoutMs = 9e4) {
    let raw = "";
    for (let p = 0; p < asset.bytes.length; p += 32768) raw += String.fromCharCode(...asset.bytes.subarray(p, p + 32768));
    const sha256 = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new Uint8Array(asset.bytes)))).map((n) => n.toString(16).padStart(2, "0")).join("");
    return new Promise((resolve, reject) => {
      const cleanup = () => {
        clearTimeout(timer);
        signal.removeEventListener("abort", abort);
      };
      const abort = () => {
        cleanup();
        reject(new LayoutError("cancelled", "\u5DF2\u53D6\u6D88\u672C\u6B21\u4E0A\u4F20\u3002"));
      };
      const timer = setTimeout(() => {
        cleanup();
        reject(new LayoutError("upload-timeout", "\u56FE\u7247\u4E0A\u4F20\u8D85\u65F6\uFF0C\u8BF7\u91CD\u8BD5\u3002"));
      }, timeoutMs);
      if (signal.aborted) {
        abort();
        return;
      }
      signal.addEventListener("abort", abort, { once: true });
      runner(tabId, "upload", expectedAccountId, { key: asset.key, base64: btoa(raw), size: asset.bytes.length, sha256, mime: asset.mime, filename: asset.filename }).then((r) => {
        cleanup();
        if (!r.ok || !isWechatImageURL(r.url) || r.account?.id !== expectedAccountId) reject(new LayoutError(r.code || "wechat-upload", r.message || "\u56FE\u7247\u4E0A\u4F20\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4\u516C\u4F17\u53F7\u3002"));
        else resolve(r.url);
      }, (e) => {
        cleanup();
        reject(e);
      });
    });
  }

  // packages/extension/src/background.ts
  var socket = (url) => new WebSocket(url);
  var connection = new ExtensionConnection({
    load: async () => {
      const saved = await chrome.storage.local.get(["pairing", "paused"]);
      return saved.paused ? null : saved.pairing ?? null;
    },
    socket,
    locate: (pairing) => locatePairing(pairing, socket),
    save: (pairing) => assistant.remember(pairing),
    readAccount: readWechatAccount,
    resolveSession: () => resolveWechatSession({ tabs: () => chrome.tabs.query({ url: "https://mp.weixin.qq.com/*" }), focused: () => chrome.tabs.query({ url: "https://mp.weixin.qq.com/*", active: true, lastFocusedWindow: true }), read: readWechatAccount }),
    upload: uploadWechatImage,
    status: () => {
    },
    state: (state) => assistant.update(state)
  });
  var assistant = new AssistantController({
    store: { get: () => chrome.storage.local.get(["pairing", "paused", "clientId", "assistantState"]), set: (value) => chrome.storage.local.set(value), remove: (key) => chrome.storage.local.remove(key) },
    connection,
    discover: () => discoverBridges(socket),
    pair: (bridge, id, waiting, signal) => requestPairing(bridge, id, socket, waiting, signal),
    publish: (state) => {
      void chrome.storage.local.set({ assistantState: state });
    }
  });
  var initialize = async () => {
    if (!await chrome.alarms.get("reconnect")) await chrome.alarms.create("reconnect", { periodInMinutes: 1 });
    await assistant.initialize();
  };
  chrome.runtime.onInstalled.addListener(() => void initialize());
  chrome.runtime.onStartup.addListener(() => void initialize());
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "reconnect") void assistant.refresh();
  });
  var tabRefresh;
  function refreshTabs() {
    clearTimeout(tabRefresh);
    tabRefresh = setTimeout(() => void assistant.refresh(), 500);
  }
  chrome.tabs.onActivated.addListener(refreshTabs);
  chrome.tabs.onRemoved.addListener(refreshTabs);
  chrome.tabs.onUpdated.addListener((_id, change, tab) => {
    if ((change.status === "complete" || change.url) && tab.url?.startsWith("https://mp.weixin.qq.com/")) refreshTabs();
  });
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL("popup.html")) return;
    const run2 = async () => {
      if (message.type === "state") return await assistant.refresh();
      if (message.type === "connect") {
        void assistant.connect(typeof message.bridgeId === "string" ? message.bridgeId : void 0);
        return { ok: true };
      }
      if (message.type === "retry") await assistant.retry();
      else if (message.type === "pause") await assistant.pause();
      else if (message.type === "disconnect") await assistant.unlink();
      else if (message.type === "open-wechat") {
        const tabs = await chrome.tabs.query({ url: "https://mp.weixin.qq.com/*" });
        const target = tabs.find((t) => t.active) || tabs[0];
        if (target?.id) {
          await chrome.tabs.update(target.id, { active: true });
          await chrome.windows.update(target.windowId, { focused: true });
        } else await chrome.tabs.create({ url: "https://mp.weixin.qq.com/" });
      }
      return assistant.snapshot;
    };
    void run2().then(respond, () => respond({ error: "\u64CD\u4F5C\u672A\u5B8C\u6210\uFF0C\u8BF7\u91CD\u8BD5" }));
    return true;
  });
  void initialize();
})();
