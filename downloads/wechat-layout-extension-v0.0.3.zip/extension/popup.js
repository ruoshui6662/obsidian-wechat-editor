"use strict";
(() => {
  // packages/extension/src/popup-view.ts
  function mountPopup(doc, port) {
    let current = { phase: "idle", message: "\u6B63\u5728\u68C0\u67E5\u8FDE\u63A5\u2026", account: null, wechatMessage: "\u6B63\u5728\u68C0\u67E5\u540E\u53F0\u2026" }, destroyed = false;
    const byId = (id) => doc.getElementById(id);
    const primary = byId("primary");
    const date = (time) => time ? new Date(time).toLocaleString("zh-CN", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "\u2014";
    function update(state) {
      if (destroyed) return;
      current = state;
      const connected = state.phase === "connected", ready2 = connected && !!state.account;
      byId("overall").textContent = ready2 ? "\u53EF\u590D\u5236\u56FE\u6587" : connected ? "\u5DF2\u8FDE\u63A5" : state.busy ? "\u8FDE\u63A5\u4E2D" : state.phase === "paused" ? "\u5DF2\u6682\u505C" : "\u672A\u8FDE\u63A5";
      byId("overall").classList.toggle("ready", ready2);
      byId("obsidian-status").textContent = connected ? "\u5DF2\u8FDE\u63A5" : state.busy ? "\u8FDE\u63A5\u4E2D" : state.phase === "paused" ? "\u5DF2\u6682\u505C" : state.phase === "reconnecting" ? "\u6062\u590D\u4E2D" : "\u672A\u8FDE\u63A5";
      byId("obsidian-status").classList.toggle("ready", connected);
      byId("vault-name").textContent = state.name || "\u672C\u673A\u7B14\u8BB0\u5E93";
      byId("vault-name").title = state.name || "";
      byId("wechat-badge").textContent = ready2 ? "\u5DF2\u5C31\u7EEA" : "\u5F85\u767B\u5F55";
      byId("wechat-badge").classList.toggle("ready", ready2);
      byId("account-name").textContent = state.account?.name || "\u81EA\u52A8\u8DDF\u968F\u5DF2\u767B\u5F55\u540E\u53F0";
      byId("wechat-status").textContent = state.wechatMessage;
      byId("status").textContent = state.message;
      primary.disabled = !!state.busy;
      primary.textContent = state.busy ? state.phase === "approval" ? "\u7B49\u5F85 Obsidian \u786E\u8BA4\u2026" : "\u6B63\u5728\u8FDE\u63A5\u2026" : connected ? ready2 ? "\u68C0\u67E5\u8FDE\u63A5" : "\u6253\u5F00\u516C\u4F17\u53F7\u540E\u53F0" : state.phase === "paused" ? "\u6062\u590D\u81EA\u52A8\u8FDE\u63A5" : "\u8FDE\u63A5 Obsidian";
      byId("connected-at").textContent = date(state.connectedAt);
      byId("disconnect-reason").textContent = state.lastDisconnect ? `${date(state.disconnectedAt)} \xB7 ${state.lastDisconnect}` : "\u2014";
      byId("version").textContent = port.version || "\u2014";
      const choices = byId("vault-choices");
      choices.replaceChildren();
      choices.hidden = !state.candidates?.length;
      for (const vault of state.candidates ?? []) {
        const button = doc.createElement("button");
        button.type = "button";
        button.textContent = vault.name;
        button.addEventListener("click", () => void action({ type: "connect", bridgeId: vault.bridgeId }));
        choices.append(button);
      }
      byId("retry").disabled = !!state.busy;
      byId("diagnostics").disabled = false;
      byId("pause").textContent = state.phase === "paused" ? "\u6062\u590D\u81EA\u52A8\u8FDE\u63A5" : state.busy ? "\u53D6\u6D88\u8FDE\u63A5" : "\u6682\u505C\u81EA\u52A8\u8FDE\u63A5";
    }
    async function action(message) {
      try {
        const response = await port.send(message);
        if (response?.phase) update(response);
        else if (response?.error) byId("status").textContent = response.error;
      } catch {
        byId("status").textContent = "\u64CD\u4F5C\u672A\u5B8C\u6210\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u52A9\u624B\u540E\u91CD\u8BD5";
      }
    }
    const listeners = [];
    const click = (id, fn) => {
      byId(id).addEventListener("click", fn);
      listeners.push(() => byId(id).removeEventListener("click", fn));
    };
    click("primary", () => {
      const type = current.phase === "connected" ? current.account ? "state" : "open-wechat" : current.phase === "paused" ? "retry" : "connect";
      if (type === "connect") primary.disabled = true;
      void action({ type });
    });
    click("retry", () => void action({ type: "retry" }));
    click("pause", () => void action({ type: current.phase === "paused" ? "retry" : "pause" }));
    click("disconnect", () => void action({ type: "disconnect" }));
    click("diagnostics", () => {
      const report = { extensionVersion: port.version, phase: current.phase, vault: current.name, message: current.message, wechatStatus: current.wechatMessage, connectedAt: current.connectedAt, lastReplyAt: current.lastReplyAt, lastDisconnect: current.lastDisconnect, disconnectedAt: current.disconnectedAt };
      void port.diagnostics(JSON.stringify(report, null, 2)).then(() => {
        byId("status").textContent = "\u8BCA\u65AD\u5DF2\u590D\u5236\uFF0C\u4E0D\u5305\u542B\u5BC6\u94A5\u3001Cookie \u6216\u6587\u7AE0\u6B63\u6587";
      }, () => {
        byId("status").textContent = "\u590D\u5236\u672A\u5B8C\u6210\uFF0C\u8BF7\u91CD\u8BD5";
      });
    });
    const ready = action({ type: "state" });
    return { ready, update, destroy: () => {
      destroyed = true;
      listeners.forEach((fn) => fn());
    } };
  }

  // packages/extension/src/popup.ts
  var ui = mountPopup(document, { send: (message) => chrome.runtime.sendMessage(message), diagnostics: (text) => navigator.clipboard.writeText(text), version: chrome.runtime.getManifest().version });
  var changed = (changes, area) => {
    if (area === "local" && changes.assistantState?.newValue) ui.update(changes.assistantState.newValue);
  };
  chrome.storage.onChanged.addListener(changed);
  window.addEventListener("unload", () => {
    chrome.storage.onChanged.removeListener(changed);
    ui.destroy();
  }, { once: true });
})();
